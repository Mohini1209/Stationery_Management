<?php
include 'sub_header.php';
?>
<div class="agileinfo-grap">
<div class="grid-form1" style="background-image:url(images/b1.jpg)">

<center>
<h3 id="forms-horizontal" align="center">Admin Login!</h3>
<form class="form-horizontal" action="check.php" method="get">
<!--<table border="1" width="50" align="center" >-->
<center>
<div class="key">
<img src="images/s5.jpg" width="300" height="100" float="left"/>
</center>
<div class="form-group">

<label for="inputEmail3" class="col-sm-7 control-label hor-form">Username</label>
    <div class="col-sm-5">
      <input type="text" name="username" class="form-control" id="inputEmail3" placeholder="Username">
    </div>
  </div>
  
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-7 control-label hor-form">Password</label>
    <div class="col-sm-5">
      <input type="password" name="password" class="form-control" id="inputPassword3" placeholder="Password">
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-7 col-sm-5">
      <div class="checkbox">
        <label>
          <input type="checkbox" name="checkbox" > Remember me
        </label>
      </div>
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-7 col-sm-5">
      <button type="submit" class="btn btn-default">Login</button>
    </div>
  </div>
</div>  
</form>
</center>


</div>


</div>
	
						<div class="clearfix"></div>
                   
	<!--//photoday-section-->	
	<!--w3-agileits-pane-->	
	<div class="w3-agileits-pane">
		
		  <div class="clearfix"></div>
	  </div>
	  <!--//w3-agileits-pane-->	
<!-- script-for sticky-nav -->
		<script>
		$(document).ready(function() {
			 var navoffeset=$(".header-main").offset().top;
			 $(window).scroll(function(){
				var scrollpos=$(window).scrollTop(); 
				if(scrollpos >=navoffeset){
					$(".header-main").addClass("fixed");
				}else{
					$(".header-main").removeClass("fixed");
				}
			 });
			 
		});
		</script>
		<!-- /script-for sticky-nav -->
<!--inner block start here-->
<div class="inner-block">

</div>
<!--inner block end here-->

<?php
if(isset($_SESSION['username'])){

include 'footer.php';
}
?>


