<?php
include 'header.php';
?>
<div class="agileinfo-grap">
<div class="grid-form1" style="background-image:url(images/b1.jpg)">


<?php
mysql_connect("localhost","root","");
mysql_select_db("stationery");
$qry=mysql_query("select * from add_product")or die(mysql_error());
?>
<table border="5" align="center">
<h1 align="center">List of Products</h1>
<tr><td>product id</td><td>category_name</td><td>sub_cat_name</td><td>product_name</td><td>price</td><td>quantity</td>
<td>total</td><td>action</td></tr>
<?php
while($data=mysql_fetch_array($qry)) 
{
$product_id=$data['product_id'];
$category_name=$data['category_name'];
$sub_cat_name=$data['sub_cat_name'];
$product_name=$data['product_name'];
$price=$data['price'];
$quantity=$data['quantity'];
$total=$data['total'];
?>
<tr>
<td><?php echo $product_id?></td>
<td><?php echo $category_name?></td>
<td><?php echo $sub_cat_name?></td>
<td><?php echo $product_name?></td>
<td><?php echo $price?></td>
<td><?php echo $quantity?></td>
<td><?php echo $total?></td>
<td><a href="pro_delete.php?product_id=<?php echo $data['product_id']?>"><button>delete</button></a>
<a href="pro_edit.php?product_id=<?php echo  $data['product_id']?>"><button>edit</button></a></td>

<?php
}
?>
</tr>
</table>


</div></div>
	
						<div class="clearfix"></div>
                   
	<!--//photoday-section-->	
	<!--w3-agileits-pane-->	
	<div class="w3-agileits-pane">
		
		  <div class="clearfix"></div>
	  </div>
	  <!--//w3-agileits-pane-->	
<!-- script-for sticky-nav -->
		<script>
		$(document).ready(function() {
			 var navoffeset=$(".header-main").offset().top;
			 $(window).scroll(function(){
				var scrollpos=$(window).scrollTop(); 
				if(scrollpos >=navoffeset){
					$(".header-main").addClass("fixed");
				}else{
					$(".header-main").removeClass("fixed");
				}
			 });
			 
		});
		</script>
		<!-- /script-for sticky-nav -->
<!--inner block start here-->
<div class="inner-block">

</div>
<!--inner block end here-->
<?php
include 'footer.php';
?>
